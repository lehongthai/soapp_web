@extends('layouts.admin')

    @section('body_right')

                
@stop