<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use DB;

class viewController extends Controller
{
    function index() {
		$catalog = DB::table('cates')->get();
		$sql = 'SELECT * FROM products ORDER BY id DESC LIMIT 8';
		$newPro = DB::select($sql);
		$sql = 'SELECT * FROM products ORDER BY RAND() LIMIT 8';
		$bestPro = DB::select($sql);
		$prod = DB::table('products')->get();
		
	    return view('index', ['catalog'=>$catalog, 'newPro'=>$newPro, 'bestPro'=>$bestPro, 'prod'=>$prod]);
	}

	function showCatalog($slug) {
		$catalog = DB::table('cates')->get();
		$ca_id = 0;
		foreach ($catalog as $ca) {
			if($ca->alias === $slug)
			{
				$ca_id = $ca->id;
			}
		}
		$sql = 'SELECT id FROM cates WHERE parent_id = "'.$ca_id.'"';
        $children = DB::select($sql);
        $array = array();
        foreach ($children as $cate) {
            array_push($array, $cate->id);
        }
        $products = DB::table('products')->whereIn('cate_id', $array)->get();
		$sql = 'SELECT * FROM products ORDER BY RAND() LIMIT 5';
		$bestPro = DB::select($sql);
		$sql = 'SELECT * FROM products ORDER BY id DESC LIMIT 5';
		$newPro = DB::select($sql);
	    return view('products.cates', ['catalog'=>$catalog, 'product'=>$products, 'bestPro'=>$bestPro, 'newPro'=>$newPro]);
	}

	public function info()
	{
		$catalog = DB::table('cates')->get();
		$post = DB::table('posts')->where('id', 9)->first();
		$myTagsId = explode(",", $post->tags);
		$myTags = DB::table('tags')->whereIn('id', $myTagsId)->get();
		return view('info', ['catalog'=>$catalog, 'post'=>$post, 'myTags'=>$myTags]);
	}

	public function phongThe()
	{
		$catalog = DB::table('cates')->get();
		return view('phongThe', ['catalog'=>$catalog]);
	}

	public function gtsp()
	{
		$catalog = DB::table('cates')->get();
		return view('gioiThieuSanPham', ['catalog'=>$catalog]);
	}

	public function post()
	{
		$catalog = DB::table('cates')->get();
		$posts = DB::table('posts')->get();
		return view('posts.allPost', ['catalog'=>$catalog, 'posts'=>$posts]);
	}

}
